import 'package:flutter/material.dart';
import 'country_select_page.dart';
import 'punishments_page.dart';
import 'rules_page.dart';
import 'dice_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background image
          Positioned.fill(
            child: Image.asset(
              'images/background.png',
              fit: BoxFit.cover,
            ),
          ),

          // Foreground content
          Center(
            child: Padding(
              padding: EdgeInsets.fromLTRB(32, 60, 32, 16),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Logo
                  Padding(
                    padding: const EdgeInsets.only(bottom: 40.0),
                    child: Image.asset(
                      'images/logo.png',
                      width: 200,
                    ),
                  ),

                  // Menu Buttons
                  _menuButton(
                    context,
                    label: 'GET QUESTIONS',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CountrySelectPage()),
                      );
                    },
                  ),
                  SizedBox(height: 20),
                  _menuButton(
                    context,
                    label: 'GET PUNISHMENTS',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => PunishmentsPage()),
                      );
                    },
                  ),
                  SizedBox(height: 20),
                  _menuButton(
                    context,
                    label: 'ROLL DICE',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => DicePage()),
                      );
                    },
                  ),
                  SizedBox(height: 20),
                  _menuButton(
                    context,
                    label: 'VIEW RULES',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => RulesPage()),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuButton(BuildContext context,
      {required String label, required VoidCallback onPressed}) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30),
        ),
        elevation: 8,
      ),
      child: Text(label, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }
}