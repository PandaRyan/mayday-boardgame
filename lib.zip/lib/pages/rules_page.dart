import 'package:flutter/material.dart';
import 'home_page.dart';

class RulesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Game Rules')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Make sure this path matches your rule image location
            Image.asset('images/rules.png', height: 400, fit: BoxFit.contain),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => HomePage()),
                  (route) => false,
                );
              },
              child: Text('Back to Menu'),
            ),
          ],
        ),
      ),
    );
  }
}