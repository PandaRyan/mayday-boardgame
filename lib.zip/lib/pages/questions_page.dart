import 'package:flutter/material.dart';
import '../game/game_manager.dart';
import 'home_page.dart';

class QuestionsPage extends StatefulWidget {
  final String country;

  QuestionsPage({required this.country});

  @override
  _QuestionsPageState createState() => _QuestionsPageState();
}

class _QuestionsPageState extends State<QuestionsPage> {
  final _game = GameManager();
  String? _questionImagePath;
  String? _correctAnswer;
  String? _userAnswer;
  bool _answered = false;

  @override
  void initState() {
    super.initState();
    _loadQuestion();
  }

  void _loadQuestion() {
    _questionImagePath = _game.getQuestion(widget.country);
    _correctAnswer = _game.getAnswer();
    _userAnswer = null;
    _answered = false;
  }

  void _handleAnswer(String choice) {
    setState(() {
      _userAnswer = choice;
      _answered = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Fullscreen background
          Positioned.fill(
            child: Image.asset(
              'images/background.png',
              fit: BoxFit.cover,
            ),
          ),

          // Foreground content
          Align(
            alignment: Alignment.topCenter,
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(top: 60, left: 24, right: 24, bottom: 40),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo
                  Image.asset('images/logo.png', width: 160),
                  SizedBox(height: 20),

                  // Enlarged question image
                  if (_questionImagePath != null)
                    Image.asset(
                      _questionImagePath!,
                      height: 400,
                      fit: BoxFit.contain,
                    ),

                  SizedBox(height: 20),

                  // A/B/C/D Buttons
                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    alignment: WrapAlignment.center,
                    children: ['A', 'B', 'C', 'D'].map((option) {
                      final isDisabled = _answered;
                      final isCorrect = _answered && option == _correctAnswer;
                      final isWrong = _answered && option == _userAnswer && option != _correctAnswer;

                      return ElevatedButton(
                        onPressed: isDisabled ? null : () => _handleAnswer(option),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isCorrect
                              ? Colors.green
                              : isWrong
                                  ? Colors.red
                                  : Colors.white,
                          foregroundColor: Colors.black,
                          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                        ),
                        child: Text(
                          option,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      );
                    }).toList(),
                  ),

                  if (_answered) ...[
                    SizedBox(height: 30),

                    // ✅ Styled answer feedback
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.7),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _userAnswer == _correctAnswer
                            ? "Correct!"
                            : "Wrong! Correct answer: $_correctAnswer",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),

                    SizedBox(height: 25),

                    // Main menu button
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (_) => HomePage()),
                          (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.black,
                        padding: EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                      ),
                      child: Text(
                        'Back to Menu',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}