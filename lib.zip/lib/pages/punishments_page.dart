import 'package:flutter/material.dart';
import '../game/game_manager.dart';
import 'home_page.dart';

class PunishmentsPage extends StatefulWidget {
  @override
  _PunishmentsPageState createState() => _PunishmentsPageState();
}

class _PunishmentsPageState extends State<PunishmentsPage> {
  final _game = GameManager();
  String? _punishmentImagePath;

  @override
  void initState() {
    super.initState();
    _punishmentImagePath = _game.getPunishment();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background
          Positioned.fill(
            child: Image.asset(
              'images/background.png',
              fit: BoxFit.cover,
            ),
          ),

          // Foreground content with scroll protection
          Align(
            alignment: Alignment.topCenter,
            child: SingleChildScrollView(
              padding: const EdgeInsets.only(top: 40, left: 24, right: 24, bottom: 40),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo
                  Image.asset('images/logo.png', width: 160),
                  SizedBox(height: 40),

                  // Punishment image
                  if (_punishmentImagePath != null)
                    Image.asset(
                      _punishmentImagePath!,
                      height: 150,
                      fit: BoxFit.contain,
                    ),

                  SizedBox(height: 40),

                  // Back to menu button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (_) => HomePage()),
                        (route) => false,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.black,
                      padding: EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Text('Back to Menu', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}