import 'dart:math';

class GameManager {
  // Singleton pattern to persist state across screens
  static final GameManager _instance = GameManager._internal();
  factory GameManager() => _instance;
  GameManager._internal();

  // Question + punishment tracking
  final Map<String, List<int>> _questionPools = {}; // Tracks [1,2,3,4] per country
  List<int> _punishmentPool = [];

  final List<List<String>> _arr = [
    ["india", "C", "B", "B", "B"],
    ["pakistan", "B", "C", "C", "C"],
    ["nepal", "A", "B", "B", "C"],
    ["srilanka", "B", "B", "A", "C"],
    ["china", "B", "C", "B", "C"],
    ["southkorea", "C", "A", "B", "D"],
    ["japan", "B", "B", "C", "B"],
    ["mongolia", "B", "C", "C", "B"],
    ["thailand", "A", "D", "C", "B"],
    ["philippines", "C", "C", "B", "A"],
    ["myanmar", "C", "A", "B", "B"],
    ["malaysia", "B", "D", "C", "C"],
    ["egypt", "C", "D", "B", "A"],
    ["saudiarabia", "B", "B", "A", "D"],
    ["uae", "C", "D", "B", "A"],
    ["turkiye", "B", "D", "C", "C"]
  ];

  String? _currentCountry;
  int _questionNum = 0;

  /// 🔁 Returns a punishment image without repeating until all 4 used
  String getPunishment() {
    final rand = Random();

    // Refill and shuffle when empty
    if (_punishmentPool.isEmpty) {
      _punishmentPool = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]..shuffle(rand);
    }

    int num = _punishmentPool.removeAt(0);
    return "images/punishment$num.png";
  }

  /// 🧠 Get a question image for selected country, avoiding repeats until reset
  String getQuestion(String country) {
    final rand = Random();
    _currentCountry = _normalizeCountry(country);

    // Initialize or refill country’s pool
    if (!_questionPools.containsKey(_currentCountry!) || _questionPools[_currentCountry!]!.isEmpty) {
      final pool = [1, 2, 3, 4]..shuffle(rand);
      _questionPools[_currentCountry!] = pool;
    }

    _questionNum = _questionPools[_currentCountry!]!.removeAt(0);
    return "images/${_currentCountry!}$_questionNum.png";
  }

  /// ✅ Get the correct answer (A–D) for current country/question
  String? getAnswer() {
    for (var entry in _arr) {
      if (entry[0] == _currentCountry) {
        return entry[_questionNum];
      }
    }
    return null;
  }

  /// Normalize country names to match internal keys
  String _normalizeCountry(String country) {
    return country.toLowerCase().replaceAll(' ', '');
  }
}